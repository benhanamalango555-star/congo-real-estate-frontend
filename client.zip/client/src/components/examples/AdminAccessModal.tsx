import AdminAccessModal from '../AdminAccessModal';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

export default function AdminAccessModalExample() {
  const [open, setOpen] = useState(false);

  return (
    <div className="p-8">
      <Button onClick={() => setOpen(true)}>Open Admin Access</Button>
      <AdminAccessModal
        open={open}
        onClose={() => setOpen(false)}
        onSuccess={() => console.log('Admin access granted!')}
      />
    </div>
  );
}
