import PropertyCard from '../PropertyCard';
import modernHouse from '@assets/generated_images/Modern_house_exterior_Congo_00755975.png';

export default function PropertyCardExample() {
  return (
    <div className="max-w-sm">
      <PropertyCard
        id="1"
        title="Maison Moderne"
        type="Maison"
        transactionType="Vente"
        price={85000000}
        city="Kinshasa"
        commune="Gombe"
        neighborhood="Quartier Résidentiel"
        rooms={4}
        image={modernHouse}
        featured={true}
        onClick={() => console.log('Property clicked')}
      />
    </div>
  );
}
