import PaymentModal from '../PaymentModal';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

export default function PaymentModalExample() {
  const [open, setOpen] = useState(false);

  return (
    <div className="p-8">
      <Button onClick={() => setOpen(true)}>Open Payment Modal</Button>
      <PaymentModal
        open={open}
        onClose={() => setOpen(false)}
        amount={1500}
        type="publish"
        onConfirm={() => {
          console.log('Payment confirmed');
          setOpen(false);
        }}
      />
    </div>
  );
}
