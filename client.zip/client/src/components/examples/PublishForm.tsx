import PublishForm from '../PublishForm';

export default function PublishFormExample() {
  return (
    <div className="max-w-4xl mx-auto p-4">
      <PublishForm onSubmit={(data) => console.log('Form data:', data)} />
    </div>
  );
}
