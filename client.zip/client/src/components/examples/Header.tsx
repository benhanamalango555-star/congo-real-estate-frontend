import Header from '../Header';

export default function HeaderExample() {
  return <Header onAdminClick={() => console.log('Admin clicked')} />;
}
